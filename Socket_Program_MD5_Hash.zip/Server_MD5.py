========================================SERVER_HASH===============================


import socket
import hashlib
IP = socket.gethostbyname(socket.gethostname())
Port = 4462
ADDR = (IP, Port)
FORMAT = "utf-8"
SIZE = 1024


def main():
    print("[Starting] Server is starting.....")
    hash1 = hashlib.md5()
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(ADDR)
    server.listen()
    print("[Listening] Server is Listening....")

    while True:
        conn, addr = server.accept()
        print(f"[New Connection] {addr} is connected..")

    def md5_hash_server():
        filename = conn.recv(SIZE).decode(FORMAT)
        print("[Recv] filename Received.")
        file = open(filename, "w")
        conn.send("Filename recieved.".encode(FORMAT))

        data = conn.recv(SIZE).decode(FORMAT)
        print(f"[RECV] File data recieved")
        file.write(data)
        conn.send("File data recieved.".encode(FORMAT))


        file.close()
        conn.close()
        print(f"[Disconnected] {ADDR} disconnected.")


if __name__ == "__main__":
    main()


