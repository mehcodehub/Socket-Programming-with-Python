================================CLIENT.HASH============================
import socket
import hashlib


IP = socket.gethostbyname(socket.gethostname())
Port = 4462
ADDR = (IP, Port)
FORMAT = "utf-8"
SIZE = 1024

def main():
   print("[Client] client starting.....")
   Client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
   Client.connect(ADDR)

   file = input("C:/Users/Srivaishnavi/Documents/Unmask.txt")
   with open(file, "rb") as file:
      data = file.read()
      #hash_1.update(data)
      my_hash = hashlib.md5(data).hexdigest();
      print(my_hash)

   Client.send("Unmask.txt".encode(FORMAT))
   msg = Client.recv(SIZE).decode(FORMAT)
   print(f"[Server]: {msg}")
   if msg == my_hash:
      print("n____success____")
   else :
      print("n....The MD5 hash failed")

   Client.send(data.encode(FORMAT))
   msg = Client.recv(SIZE).decode(FORMAT)
   print(f"[Server]: {msg}")

   file.close()
   Client.close()

if __name__ == "__main__":
   main()

